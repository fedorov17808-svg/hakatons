# @creditpulse/sdk

Official Developer SDK for integrating **CreditPulse AI** real-time institutional credit ratings and dynamic risk-adjusted LTV into your DeFi and RWA protocols on **Creditcoin (CC3)**.

> **One import. One function call. Institutional-grade credit data on-chain.**

---

## 📦 Installation

```bash
npm install @creditpulse/sdk ethers
```

---

## ⚡ Quickstart — Fetch a Credit Score

```typescript
import { CreditPulseSDK } from "@creditpulse/sdk";

const sdk = new CreditPulseSDK();

// Fetch live on-chain credit report for Aave V3
const report = await sdk.getRiskReport("0x87870Bca3F3fD6335C3F4ce8392D69350B4fA4E2");
console.log(`Credit Rating: ${report.overall}/100`);
console.log(`Liquidity: ${report.liquidity} | Security: ${report.security} | Collateral: ${report.collateral}`);
```

---

## 💰 Dynamic Loan Terms (Risk-Adjusted LTV & APR)

```typescript
const terms = sdk.calculateLoanTerms(report.overall);
console.log(`Tier: ${terms.tier}`);       // "AAA" | "AA" | "A" | "BBB" | "HighRisk"
console.log(`Max LTV: ${terms.ltvPercent}%`);  // 85% for AAA, 45% for HighRisk
console.log(`APR: ${terms.aprPercent}%`);      // 3.5% for AAA, 18% for HighRisk
console.log(`Eligible: ${terms.isEligible}`);  // false if score < 25
```

---

## 📡 Real-Time Event Subscription

```typescript
// Subscribe to new credit reports as they land on-chain
sdk.onReportSaved((event) => {
  console.log(`New report for ${event.assetAddress}: score ${event.overallScore}/100`);
  console.log(`Cross-chain verified: ${event.crossChainVerified}`);
  
  // Auto-adjust your protocol's risk parameters
  if (event.overallScore < 50) {
    pauseLending(event.assetAddress);
  }
});
```

---

## 📊 Report History & Finalization Status

```typescript
// Get full scoring history for an asset
const history = await sdk.getReportHistory("0x87870Bca3F3fD6335C3F4ce8392D69350B4fA4E2");
console.log(`Total reports: ${history.length}`);

// Check if a report has passed the optimistic dispute window
const isFinalized = await sdk.isReportFinalized("0x87870...", 0);
console.log(`Report #0 finalized: ${isFinalized}`); // true after 3-day window
```

---

## 📜 Solidity Integration (1-Line Protocol Integration)

```solidity
import "@creditpulse/contracts/interfaces/ICreditPulse.sol";

contract MyLendingPool {
    ICreditPulse public immutable creditPulse = ICreditPulse(0x358925c5839a36bB2181786B8763Da0653B0f438);

    function borrow(address collateralAsset, uint256 amount) external {
        ICreditPulse.RiskReport memory report = creditPulse.getRiskReport(collateralAsset);
        require(report.overallScore >= 75, "Collateral asset credit rating below institutional threshold");
        // Proceed with dynamic loan origination
    }
}
```

---

## 🔧 API Reference

| Method | Returns | Description |
|:---|:---|:---|
| `getRiskReport(address)` | `RiskScores` | Latest 7-vector credit scores |
| `calculateLoanTerms(score)` | `DynamicLoanTerms` | Risk-adjusted LTV, APR, tier |
| `getReportHistory(address)` | `RiskScores[]` | Full on-chain scoring history |
| `isReportFinalized(address, idx)` | `boolean` | Dispute window status |
| `getAssetReportCount(address)` | `number` | Total reports for asset |
| `onReportSaved(callback)` | `void` | Real-time event listener |
| `getProtocolStats()` | `ProtocolStats` | Quorum, staking, insurance TVL |

---

## ⚙️ Configuration

```typescript
const sdk = new CreditPulseSDK({
  rpcUrl: "https://rpc.cc3-testnet.creditcoin.network",     // Custom RPC
  contractAddress: "0x358925c5839a36bB2181786B8763Da0653B0f438", // Custom contract
  maxRetries: 3,        // Retry failed RPC calls
  retryDelayMs: 1000,   // Delay between retries
  timeoutMs: 15000,     // RPC timeout
});
```

---

## 📋 License

MIT — Built by the CreditPulse AI Core Team.

